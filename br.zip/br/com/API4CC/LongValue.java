package br.com.API4CC;

public class LongValue
{
    public long value;
    
    public LongValue(long i)
    {
        value = i;
    }
}